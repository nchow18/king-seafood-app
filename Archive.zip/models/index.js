const Product = require('./Product');
const Detail = require('./Detail');

module.exports = { Product, Detail }