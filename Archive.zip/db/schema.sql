DROP DATABASE IF EXISTS king_seafood_db;
CREATE DATABASE king_seafood_db;