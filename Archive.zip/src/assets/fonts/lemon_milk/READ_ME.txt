LEMON MILK.otf ver 5.0 (donationware)

     Need lowercases of LEMON MILK?

     Wait no more! LEMON MILK Pro is available now. 
     Get LEMON MILK with lowercases, covering extended Latin, Cyrillic, and Greek. 
     Moreover, it now has 18 fonts + 2 variable fonts ranging from thin to heavy.

  >> Go check https://www.marsnev.com now to learn more. <<


----------IMPORTANT NOTE----------

This version of LEMON MILK is absolutely free for personal, educational, non-profit, or charitable use. 
For commercial use, kindly donate me (pay as you want) as an appreciation. If you want to donate, my PayPal address is marsnev@marsnev.com
Every donation is greatly appreciated. 

If you need further information,
kindly check my F.A.Q page at: http://blog.marsnev.com/p/faq.html

if you cannot get the answers there,
kindly contact me at:
email address: marsnev@marsnev.com



Thanks for being supportive,
MARSNEV

https://www.marsnev.com
twitter.com/MARSNEV
instagram.com/MARSNEV
behance.com/MARSNEV

