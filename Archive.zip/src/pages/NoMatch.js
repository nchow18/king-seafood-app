import React from 'react';

function NoMatch() {
    return (
        <>
          <div className="flex-c-column content">
              ERROR PAGE NOT FOUND                
          </div>
        </>
    )
}

export default NoMatch;